import java.io.*;
public class Busqueda
{
    public static String busqueda(String cadena,String dato){
        String a="";
        String [] b=cadena.split(":");
        //for(String nombres:nombre){
            if(cadena.toLowerCase().contains(dato.toLowerCase())){
                a+=b[0]+",";
            }
        //}
        return a.substring(0,a.length());
    }
    public static String leerarchivo(String nombre){
        String cadena="";
        String cadena2="";
        try{
            FileReader fr=new FileReader(nombre+".txt");
            BufferedReader br= new BufferedReader(fr);
            
            while((cadena=br.readLine())!=null){
                cadena2+=cadena+",";
                
            }
            
        }catch(Exception e){
            System.out.println("no hay archivo");
            return "";
        }
        
        return cadena2;
    }
    public static void main(String []args){
        String []a=leerarchivo("nota").split(",");
        String s="";
        for(String b:a){
            s+=busqueda(b,"una");
        }
        System.out.println("las notas con el nombre: "+s+" contienen la palabra buscada");
    }
}
